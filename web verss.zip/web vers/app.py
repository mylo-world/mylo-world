from flask import Flask, render_template, request, redirect, url_for, session
import os

app = Flask(__name__)
app.secret_key = 'roseisred'  # Change this to a random secret key

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def load_scores(file_path="scores.txt"):
    player_scores = {}
    try:
        with open(file_path, "r") as file:
            for line in file:
                name, score = line.strip().split(":")
                player_scores[name] = int(score)
    except FileNotFoundError:
        player_scores = {}
    return player_scores

def save_scores(player_scores, file_path="scores.txt"):
    with open(file_path, "w") as file:
        for name, score in player_scores.items():
            file.write(f"{name}:{score}\n")

player_scores = load_scores()

@app.route('/')
def start_menu():
    return render_template('startmenu.html')

@app.route('/login', methods=['POST'])
def user_login():
    username = request.form.get('username')
    if username:
        session['username'] = username
        if username not in player_scores:
            player_scores[username] = 0  # Initialize score
            save_scores(player_scores)  # Save new user to file
        # Redirect to the select_category route
        return redirect(url_for('select_category'))  # Correct usage
    return redirect(url_for('start_menu'))  # Correct usage

@app.route('/leaderboard')
def leaderboard():
    sorted_scores = sorted(player_scores.items(), key=lambda x: x[1], reverse=True)[:5]
    return render_template('leaderboard.html', scores=sorted_scores)

@app.route('/select_category')
def select_category():
    return render_template('selectcategory.html')

@app.route('/level_selection/<category>')
def level_selection(category):
    return render_template('levelselection.html', category=category)

@app.route('/main_game/<category>/<level>')
def main_game(category, level):
    return render_template('maingame.html', category=category, level=level)

@app.route('/win')
def win():
    return render_template('win.html')

@app.route('/lose')
def lose():
    return render_template('lose.html')

if __name__ == '__main__':
    app.run(debug=True)
